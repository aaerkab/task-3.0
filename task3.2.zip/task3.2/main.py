import math
from tkinter import *

root = Tk()
w, h = 500, 500

root.geometry(f'{w}x{h}')
root.config(background='black')
canvas = Canvas(root, width=w, height=h, background='black', highlightthickness=0)
canvas.pack()


period = h / 2
y = h / 2
x = w / 2
r = 20
dt = 0.01

air_resistance = 0.4
acceleration_ratio = 0.01
circle = canvas.create_oval(x - r, y - r, x + r, y + r, fill='#aaa', outline='#fff', width=3)

def tick(time: float, prev_y: float, ac_f: float):

    damping_factor = math.exp(-air_resistance * time)
    acceleration_factor = ac_f + acceleration_ratio
    position = h - math.fabs(math.cos(time * acceleration_factor) * period * damping_factor) - r

    dy = position - prev_y

    canvas.move(circle, 0, dy)

    root.after(10, lambda: tick(time + dt, position, acceleration_factor))

tick(0, y, 1)



root.mainloop()





