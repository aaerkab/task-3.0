import math
from tkinter import *
from typing import List

from RoundedButton import CustomButton

root = Tk()

circle_radius = 25
number_of_bits = 10
margin = 50

w, h = (circle_radius * 2 + margin) * number_of_bits + 100, 300

root.geometry(f'{w}x{h}')


left_margin = (w - (circle_radius * 2 * number_of_bits) - (margin * number_of_bits)) // 2

inactive_bg = 'black'
active_bg = 'yellow'
inactive_text = 'white'
active_text = 'black'

buttons: List[CustomButton] = []
states: List[bool] = []
text_template = 'Текущее число: '

sum_text = Label(root, text=text_template + "0")
sum_text.place(x=50, y=50)

def recount():
    current_sum = 0

    for state in range(len(states)):
        current_sum += 2 ** (number_of_bits - 1 - state) if states[state] else 0

    sum_text.config(text=text_template + str(current_sum))


def get_printer(ind: int):
    def result():
        if ind < len(buttons):
            current_button = buttons[ind]
            states[ind] = not states[ind]
            new_back = active_bg if states[ind] else inactive_bg
            new_text = active_text if states[ind] else inactive_text
            current_button.setColor((new_back, new_text))
        else:
            print("Первый старт")
        recount()

    return result


for i in range(number_of_bits):
    states.append(False)

    current_center_x = i * (circle_radius * 2 + margin) + circle_radius + left_margin

    button = CustomButton(root, circle_radius * 2, circle_radius * 2, inactive_bg, str(2 ** (number_of_bits - 1 - i)),
                          command=get_printer(i))
    buttons.append(button)
    button.place(x=current_center_x - circle_radius, y=h // 2 - circle_radius)

root.mainloop()
