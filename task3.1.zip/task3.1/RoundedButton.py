import tkinter as tk
from typing import Tuple


class CustomButton(tk.Canvas):
    def __init__(self, parent, width, height, color, text: str, command=None, **kwargs):
        tk.Canvas.__init__(self, parent, borderwidth=0,
                           relief="raised", highlightthickness=0, **kwargs)
        self.command = command
        self.text = text
        padding = 4
        self.padding = padding
        self.background_circle = self.create_oval((padding, padding,
                               width + padding, height + padding), outline=color, fill=color)
        (x0, y0, x1, y1) = self.bbox("all")

        width = (x1 - x0) + padding
        height = (y1 - y0) + padding

        self.configure(width=width, height=height)
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)

        self.label_text = self.create_text(width // 2, height // 2, text=text, fill='white', font=('Helvetica 11 bold'), anchor='center')

    def setColor(self, color: Tuple[str, str]):
        self.itemconfig(self.background_circle, fill=color[0], outline=color[0])
        self.itemconfig(self.label_text, fill=color[1])

    def _on_press(self, event):
        self.configure(relief="sunken")

    def _on_release(self, event):
        self.configure(relief="raised")
        if self.command is not None:
            self.command()
