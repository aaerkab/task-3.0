import math
from tkinter import *

root = Tk()

canvas = Canvas(root, width=600, height=600, bg='white')
canvas.pack()
# Установка размера окна
root.geometry('600x600')

# Отрисовка главной окружности
main_circle = canvas.create_oval(100, 100, 500, 500, fill='green')

# Переменная, отвечающая за скорость и направление движения точки.
# Меньше 0 - по часовой стрелке, больше 0 - против часовой стрелки
# Больше модуль числа - больше скорость движения
dt: float = -0.001

start_x = 400
start_y = 100
ball_radius = 5

# Отрисовка точки
ball = canvas.create_oval(start_x - ball_radius,
                          start_y - ball_radius,
                          start_x + ball_radius,
                          start_y + ball_radius,
                          fill='red')

#Функция движения
def motion(x: float, y: float, angle: float):
    # Расчет нового положения точки
    new_x, new_y = 200 * math.cos(angle) + 300, -200 * math.sin(angle) + 300
    # Расчет смещения точки
    dx, dy = new_x - x, new_y - y
    # Смещение точки
    canvas.move(ball, dx, dy)
    # Вызов функции движения через 10мс с измененным углом
    root.after(10, lambda: motion(new_x, new_y, angle + dt))


motion(start_x, start_y, 0)

root.mainloop()
